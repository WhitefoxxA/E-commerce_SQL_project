USE ecommerce;
SHOW TABLES;
-- 1. Total Sales by Employee: 
-- Write a query to calculate the total sales (in dollars) made by each employee, 
-- considering the quantity and unit price of products sold

SELECT
CONCAT(e.FirstName," ", e.LastName) AS Employee_name,
CONCAT('$', FORMAT(SUM(d.Quantity * d.UnitPrice),2)) AS Total_Sales
FROM Employees e
JOIN Orders o
ON e.EmployeeID = o.EmployeeID
JOIN OrderDetails d
ON o.OrderID = d.OrderID
GROUP BY Employee_name
ORDER BY Total_Sales DESC;

-- 2. Top 5 Customers by Sales:
-- Identify the top 5 customers who have generated the most revenue
-- Show the customer’s name and the total amount they spent

SELECT c.CustomerName,
CONCAT('$', FORMAT(SUM(d.Quantity * d.UnitPrice),2)) AS Total_Expense
FROM Customers c
JOIN Orders o
ON c.CustomerID = o.CustomerID
JOIN OrderDetails d
ON o.OrderID = d.OrderID
GROUP BY c.CustomerID, c.CustomerName
ORDER BY Total_Expense
LIMIT 5;

-- 3. Monthly Sales Trend:
-- Write a query to display the total sales amount for each month in the year 1997.
SELECT date_format(o.OrderDate, '%Y-%m') AS Month,
CONCAT('$', FORMAT(SUM(d.Quantity * d.UnitPrice),2)) AS Total_Sales
FROM Orders o
JOIN OrderDetails d
ON o.OrderID = d.OrderID
WHERE YEAR(o.OrderDate) = 1997
GROUP BY date_format(o.OrderDate, '%Y-%m')
ORDER BY MONTH;

-- 4. Order Fulfilment Time:
-- Calculate the average time (in days) taken to fulfil an order for each employee. 
-- Assuming shipping takes 3 or 5 days respectively depending on if the item was ordered in 1996 or 1997.
SELECT e.FirstName,
CONCAT(ROUND(AVG(
CASE
	WHEN YEAR(o.OrderDate) = 1996 THEN 3
	WHEN YEAR(o.OrderDate) = 1997 THEN 5
	ELSE 0
END
),0),' ','Days'
) AS AVG_FULFILMENT_DAYS
FROM Employees e
JOIN Orders o
ON e.EmployeeID = O.EmployeeID
GROUP BY e.FirstName
ORDER BY AVG_FULFILMENT_DAYS;

-- 5. Products by Category with No Sales:
-- List the customers operating in London and total sales for each. 
SELECT c.CustomerName, City,
CONCAT('$', FORMAT(SUM(d.Quantity * d.UnitPrice),2))AS Total_Sales
FROM Customers c
JOIN Orders o
ON c.CustomerID = o.CustomerID
JOIN OrderDetails d
ON o.OrderID = d.OrderID
WHERE c.City = 'London'
GROUP BY c.CustomerName
ORDER BY Total_Sales;

-- 6. Customers with Multiple Orders on the Same Date:
-- Write a query to find customers who have placed more than one order on the same date.
SELECT c.CustomerName, o.OrderDate,
Count(o.OrderID) AS Amount_of_orders
FROM Customers c
JOIN Orders o
ON c.CustomerID = o.CustomerID
GROUP BY c.CustomerName, o.OrderDate
HAVING COUNT(o.OrderID)> 1
ORDER BY Amount_of_orders;

-- 7. Average Discount per Product:
-- Calculate the average discount given per product across all orders. Round to 2 decimal places.
SELECT p.ProductName,
ROUND(AVG(d.Discount),2) AS Avg_Discount
FROM Products p
JOIN OrderDetails d
ON p.ProductID = d.ProductID
GROUP BY p.ProductName
ORDER BY Avg_Discount;

-- 8. Products Ordered by Each Customer:
-- For each customer, list the products they have ordered along with the total quantity of each product ordered.
SELECT c.CustomerName, p.ProductName,
SUM(d.Quantity) AS Total_Quantity
FROM Customers c
JOIN Orders o
ON c.CustomerID = o.CustomerID
JOIN OrderDetails d
ON o.OrderID = d.OrderID
JOIN Products p
ON d.ProductID = p.ProductID
GROUP BY c.CustomerName, p.ProductName
ORDER BY Total_Quantity;

-- 9. Employee Sales Ranking:
-- Rank employees based on their total sales. Show the employeename, total sales, and their rank.
SELECT 
CONCAT(e.FirstName," ", e.LastName) AS Employee_Name,
CONCAT('$', FORMAT(SUM(d.Quantity * d.UnitPrice * (1 - d.Discount)),2)) AS Total_Sales,
RANK() OVER (ORDER BY SUM(d.Quantity * d.UnitPrice * (1 - d.Discount))) AS Sales_Rank
FROM Employees e
JOIN Orders o
ON e.EmployeeID = o.EmployeeID
JOIN OrderDetails d
ON o.OrderID = d.OrderID
GROUP BY Employee_Name
ORDER BY Sales_Rank;   -- customer,orders,orderdetails,products,categories

-- 10. Sales by Country and Category:
-- Write a query to display the total sales amount for each product category, grouped by country.
SELECT c.Country, ca.CategoryName,
CONCAT('$', FORMAT(SUM(p.Unit * p.Price),2)) AS Total_Sales
FROM Customers c
JOIN Orders o
ON c.CustomerID = o.CustomerID
JOIN OrderDetails d
ON o.OrderID = d.OrderID
JOIN Products p
ON d.ProductID = p.ProductID
JOIN Categories ca
ON p.CategoryID = ca.CategoryID
GROUP BY c.Country, ca.CategoryName
ORDER BY c.Country, ca.CategoryName;

-- 11. Year-over-Year Sales Growth:
-- Calculate the percentage growth in sales from one year to the next for each product.
/*SELECT p.ProductID, p.ProductName,
YEAR(o.OrderDate) AS Order_Year,
SUM(d.Quantity * d.UnitPrice) AS Total_Sales
FROM Orders o
JOIN OrderDetails d 
ON o.OrderID = d.OrderID
JOIN Products p 
ON d.ProductID = p.ProductID
GROUP BY p.ProductID, p.ProductName, Order_Year
ORDER BY p.ProductID, Order_Year;*/
SELECT t1.ProductID,
    t1.ProductName,
    t1.Order_Year,
    t1.Total_Sales,
    t2.Total_Sales AS Previous_Year_Sales,
    ((t1.Total_Sales - t2.Total_Sales) / t2.Total_Sales) * 100 AS Percentage_Growth
FROM
(
SELECT p.ProductID, p.ProductName,
YEAR(o.OrderDate) AS Order_Year,
SUM(d.Quantity * d.UnitPrice) AS Total_Sales
FROM Orders o
JOIN OrderDetails d 
ON o.OrderID = d.OrderID
JOIN Products p 
ON d.ProductID = p.ProductID
GROUP BY p.ProductID, p.ProductName, Order_Year
) AS t1
JOIN
(
SELECT p.ProductID, p.ProductName,
YEAR(o.OrderDate) AS Order_Year,
SUM(d.Quantity * d.UnitPrice) AS Total_Sales
FROM Orders o
JOIN OrderDetails d 
ON o.OrderID = d.OrderID
JOIN Products p 
ON d.ProductID = p.ProductID
GROUP BY p.ProductID, p.ProductName, Order_Year
) AS t2
 ON t1.ProductID = t2.ProductID AND t1.Order_Year = t2.Order_Year + 1
ORDER BY t1.ProductID, t1.Order_Year;


-- 12. Order Quantity Percentile:
-- Calculate the percentile rank of each order based on the total quantity of products in the order. 
SELECT o.OrderID,
SUM(d.Quantity) AS Total_Quantity
FROM Orders o
JOIN Orderdetails d 
ON o.OrderID = d.OrderID
GROUP BY o.OrderID;
SELECT OrderID,Total_Quantity,
PERCENT_RANK() OVER (ORDER BY Total_Quantity) AS Quantity_Percentile
FROM (
SELECT o.OrderID,
SUM(d.Quantity) AS Total_Quantity
FROM Orders o
JOIN Orderdetails d
 ON o.OrderID = d.OrderID
GROUP BY o.OrderID
) AS Order_Totals
ORDER BY Total_Quantity;

-- 13. Products Never Reordered:
-- Identify products that have been sold but have never been reordered (ordered only once). 
SELECT p.ProductID, p.ProductName
FROM Products p
JOIN OrderDetails d
ON p.ProductID = d.ProductID
GROUP BY p.ProductID, p.ProductName
HAVING COUNT(Distinct d.OrderID) = 1;

-- 14.  Most Valuable Product by Revenue:
-- Write a query to find the product that has generated the most revenue in each category.

DROP VIEW IF EXISTS Product_revenue;

CREATE VIEW Product_revenue AS
SELECT p.ProductID,p.ProductName,ca.CategoryID,ca.CategoryName,
CONCAT('$', FORMAT(SUM(d.Quantity * d.UnitPrice),2)) AS Revenue
FROM OrderDetails d
JOIN Products p 
ON d.ProductID = p.ProductID
JOIN Categories ca 
ON p.CategoryID = ca.CategoryID
GROUP BY p.ProductID, p.ProductName, ca.CategoryID, ca.CategoryName;
SELECT * FROM Product_revenue;
SELECT pr.CategoryName, pr.ProductName, pr.revenue
FROM Product_revenue pr
WHERE pr.revenue = (
    SELECT MAX(Revenue)
    FROM Product_revenue
    WHERE CategoryID = pr.CategoryID
    
);

-- 15. Complex Order Details:
-- Identify orders where the total price of all items exceeds $100 and contains at least one product with a discount of 5% or more.
SELECT o.OrderID,
SUM(d.Quantity * d.UnitPrice * (1 - d.Discount)) AS Total_order_price
FROM Orders o
JOIN OrderDetails d
ON o.OrderID = d.OrderID
GROUP BY o.OrderID
HAVING Total_order_price > 100
   AND MAX(d.Discount) >= 0.05;




SELECT t1.ProductID,
    t1.ProductName,
    t1.Order_Year,
    t1.Total_Sales,
    t2.Total_Sales AS Previous_Year_Sales,
    ((t1.Total_Sales - t2.Total_Sales) / t2.Total_Sales) * 100 AS Percentage_Growth
FROM
(
SELECT p.ProductID, p.ProductName,
YEAR(o.OrderDate) AS Order_Year,
SUM(d.Quantity * d.UnitPrice) AS Total_Sales
FROM Orders o
JOIN OrderDetails d 
ON o.OrderID = d.OrderID
JOIN Products p 
ON d.ProductID = p.ProductID
GROUP BY p.ProductID, p.ProductName, Order_Year
) AS t1
JOIN
(
SELECT p.ProductID, p.ProductName,
YEAR(o.OrderDate) AS Order_Year,
SUM(d.Quantity * d.UnitPrice) AS Total_Sales
FROM Orders o
JOIN OrderDetails d 
ON o.OrderID = d.OrderID
JOIN Products p 
ON d.ProductID = p.ProductID
GROUP BY p.ProductID, p.ProductName, Order_Year
) AS t2
 ON t1.ProductID = t2.ProductID AND t1.Order_Year = t2.Order_Year + 1
ORDER BY t1.ProductID, t1.Order_Year;